o Description o
Name:         Safrad (Chess engine of SDG - Safrad's Desk Games)
Version:      2.2 (executable file contains release and build)
Description:  UCI Chess Engine for Win32
Author:       David Safranek (Safrad)
E-Mail:       safrad at email.cz
Web:          http://safrad.own.cz/Software/Safrad/
Protocol:     UCI2 (Universal Chess Interface - Version 2) - see http://www.chess-download.net/uci.zip for commands

o Installation o
Engine can be used with any UCI-compliant GUI (Graphical User Interface)
- Arena
- Chessbase / Fritz
- Chess Assistant
- Chess Partner
Arena is free and can be downloaded from
http://www.playwitharena.com/download/


o Configuration o
Modify the file "Engine.ini" for changing startup UCI configuration, or delete it when you want to use default configuration. 


o Algorithm o
Program uses negamax algorithm (simpler variantion of minimax), many prunings (alpha-beta, futility, history and killer heuristics) and hash table.
Chess rating is about 1700 ELO on 1800MHz CPU (Axon Bench PowX=6).
Program has also own GUI, which allows to play variants and other board games.

o Transposition table size o
Each hash entry takes 16 bytes. The size of the transposition table may be changed by the user but can be only a power of 2.
By default, table size is 16MB.

Does not support Winboard protocol.
Does not support Nalimov tablebases (endgame databases).

o Version History o

Version 2.2
- added games othello, blob wars

Version 2.1
- plays games like chess, draughts, go-moku, explosion and variants, for example mini-chess described with FEN kqbnr/ppppp/5/PPPPP/KQBNR w Kk - 0 1
- UCI (Universal Chess Interface) for chess variants available
- program separated to GUI and Engine

Version 2.0
- 32-bit Win32 version

Version 1.1
- game format changed

Version 1.0
- 16-bit DOS version plays only english draughts


o License o
See the file "License.txt" for details.


Prague, Czech Republic
2006-04-11, David Safranek
